<?php
$wp_swc_blacklist = array (
		array (
				'id' => '1',
				'botnickname' => 'Semalt',
				'botname' => 'Semalt Bot',
				'boturl' => 'semalt.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '2',
				'botnickname' => 'Buttons-for-website',
				'botname' => 'buttons-for-website Bot',
				'boturl' => 'buttons-for-website.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '3',
				'botnickname' => 'darodar',
				'botname' => 'darodar Bot',
				'boturl' => 'darodar.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '4',
				'botnickname' => 'Social Buttons',
				'botname' => 'Social buttons Bot',
				'boturl' => 'social-buttons.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '5',
				'botnickname' => 'Make Money Online',
				'botname' => 'Make Money Online Bot',
				'boturl' => '7makemoneyonline.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '6',
				'botnickname' => 'I Love Vitaly',
				'botname' => 'I Love Vitaly Bot',
				'boturl' => 'ilovevitaly.co',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '7',
				'botnickname' => 'simple-share-buttons.com',
				'botname' => 'simple-share-buttons.com',
				'boturl' => 'simple-share-buttons.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '8',
				'botnickname' => 'clicksor.com',
				'botname' => 'clicksor.com',
				'boturl' => 'clicksor.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '9',
				'botnickname' => 'bestwebsitesawards.com',
				'botname' => 'bestwebsitesawards.com',
				'boturl' => 'bestwebsitesawards.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '10',
				'botnickname' => 'aliexpress.com',
				'botname' => 'aliexpress.com',
				'boturl' => 'aliexpress.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '11',
				'botnickname' => 'savetubevideo.com',
				'botname' => 'savetubevideo.com',
				'boturl' => 'savetubevideo.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '12',
				'botnickname' => 'kambasoft.com',
				'botname' => 'kambasoft.com',
				'boturl' => 'kambasoft.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '13',
				'botnickname' => 'priceg.com',
				'botname' => 'priceg.com',
				'boturl' => 'priceg.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '14',
				'botnickname' => 'blackhatworth.com',
				'botname' => 'blackhatworth.com',
				'boturl' => 'blackhatworth.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '15',
				'botnickname' => 'hulfingtonpost.com',
				'botname' => 'hulfingtonpost.com',
				'boturl' => 'hulfingtonpost.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '16',
				'botnickname' => 'econom.co',
				'botname' => 'econom.co',
				'boturl' => 'econom.co',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '17',
				'botnickname' => 'ranksonic.org',
				'botname' => 'ranksonic.org',
				'boturl' => 'ranksonic.org',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '18',
				'botnickname' => 'ranksonic.info',
				'botname' => 'ranksonic.info',
				'boturl' => 'ranksonic.info',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '19',
				'botnickname' => '4webmasters.org',
				'botname' => '4webmasters.org',
				'boturl' => '4webmasters.org',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '20',
				'botnickname' => 'anticrawler.org',
				'botname' => 'anticrawler.org',
				'boturl' => 'anticrawler.org',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '21',
				'botnickname' => 'bestsub.com',
				'botname' => 'bestsub.com',
				'boturl' => 'bestsub.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '22',
				'botnickname' => 'o-o-6-o-o.com',
				'botname' => 'o-o-6-o-o.com',
				'boturl' => 'o-o-6-o-o.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '23',
				'botnickname' => 'sitequest.ru',
				'botname' => 'sitequest.ru',
				'boturl' => 'sitequest.ru',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '24',
				'botnickname' => 'search.tb.ask.com',
				'botname' => 'search.tb.ask.com',
				'boturl' => 'search.tb.ask.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '25',
				'botnickname' => 'wow.com',
				'botname' => 'wow.com',
				'boturl' => 'wow.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '26',
				'botnickname' => 'adviceforum.info',
				'botname' => 'adviceforum.info',
				'boturl' => 'adviceforum.info',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '27',
				'botnickname' => 'makemoneyonline.com',
				'botname' => 'makemoneyonline.com',
				'boturl' => 'makemoneyonline.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '28',
				'botnickname' => 'best-seo-solution.com',
				'botname' => 'best-seo-solution.com',
				'boturl' => 'best-seo-solution.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '29',
				'botnickname' => 'get-free-traffic-now.com',
				'botname' => 'get-free-traffic-now.com',
				'boturl' => 'get-free-traffic-now.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '30',
				'botnickname' => 'buy-cheap-online.info',
				'botname' => 'buy-cheap-online.info',
				'boturl' => 'buy-cheap-online.info',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '31',
				'botnickname' => 'best-seo-offer.com',
				'botname' => 'best-seo-offer.com',
				'boturl' => 'best-seo-offer.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '32',
				'botnickname' => 'buttons-for-your-website.com',
				'botname' => 'buttons-for-your-website.com',
				'boturl' => 'buttons-for-your-website.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '33',
				'botnickname' => 'googlsucks.com',
				'botname' => 'googlsucks.com',
				'boturl' => 'googlsucks.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '34',
				'botnickname' => 'pornhub-forum.ga',
				'botname' => 'pornhub-forum.ga',
				'boturl' => 'pornhub-forum.ga',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '35',
				'botnickname' => 'depositfiles-porn.ga',
				'botname' => 'depositfiles-porn.ga',
				'boturl' => 'depositfiles-porn.ga',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '36',
				'botnickname' => 'theguardlan.com',
				'botname' => 'theguardlan.com',
				'boturl' => 'theguardlan.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '37',
				'botnickname' => 'torture.ml',
				'botname' => 'torture.ml',
				'boturl' => 'torture.ml',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '38',
				'botnickname' => 'youporn-forum.ga',
				'botname' => 'youporn-forum.ga',
				'boturl' => 'youporn-forum.ga',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '39',
				'botnickname' => 'hol.es',
				'botname' => 'hol.es',
				'boturl' => 'hol.es',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '40',
				'botnickname' => 'domination.ml',
				'botname' => 'domination.ml',
				'boturl' => 'domination.ml',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '41',
				'botnickname' => 'free-share-buttons.com',
				'botname' => 'free-share-buttons.com',
				'boturl' => 'free-share-buttons.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '42',
				'botnickname' => 'uni.me',
				'botname' => 'uni.me',
				'boturl' => 'uni.me',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '43',
				'botnickname' => 'sashagreyblog.ga',
				'botname' => 'sashagreyblog.ga',
				'boturl' => 'sashagreyblog.ga',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '44',
				'botnickname' => 'search.myway.com',
				'botname' => 'search.myway.com',
				'boturl' => 'search.myway.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '45',
				'botnickname' => 'guardlink.com',
				'botname' => 'guardlink.com',
				'boturl' => 'guardlink.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '46',
				'botnickname' => 'event-tracking.com',
				'botname' => 'event-tracking.com',
				'boturl' => 'event-tracking.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '47',
				'botnickname' => 'free-social-buttons.com',
				'botname' => 'free-social-buttons.com',
				'boturl' => 'free-social-buttons.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '48',
				'botnickname' => 'kabbalah-red-bracelets.com',
				'botname' => 'kabbalah-red-bracelets.com',
				'boturl' => 'kabbalah-red-bracelets.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '49',
				'botnickname' => 'guardlink.org',
				'botname' => 'guardlink.org',
				'boturl' => 'guardlink.org',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '50',
				'botnickname' => 'sanjosestartups.com',
				'botname' => 'sanjosestartups.com',
				'boturl' => 'sanjosestartups.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '51',
				'botnickname' => '100dollars-seo.com',
				'botname' => '100dollars-seo.com',
				'boturl' => '100dollars-seo.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '52',
				'botnickname' => 'howtostopreferralspam.eu',
				'botname' => 'howtostopreferralspam.eu',
				'boturl' => 'howtostopreferralspam.eu',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '53',
				'botnickname' => 'ertelecom.ru',
				'botname' => 'ertelecom.ru',
				'boturl' => 'ertelecom.ru',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '54',
				'botnickname' => 'corbina.ru',
				'botname' => 'corbina.ru',
				'boturl' => 'corbina.ru',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '55',
				'botnickname' => 'floating-share-buttons.com',
				'botname' => 'floating-share-buttons.com',
				'boturl' => 'floating-share-buttons.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '56',
				'botnickname' => 'mts-nn.ru',
				'botname' => 'mts-nn.ru',
				'boturl' => 'mts-nn.ru',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '57',
				'botnickname' => 'kes.ru',
				'botname' => 'kes.ru',
				'boturl' => 'kes.ru',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '58',
				'botnickname' => 'bashtel.ru',
				'botname' => 'bashtel.ru',
				'boturl' => 'bashtel.ru',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '59',
				'botnickname' => 'is74.ru',
				'botname' => 'is74.ru',
				'boturl' => 'is74.ru',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '60',
				'botnickname' => 'netbynet.ru',
				'botname' => 'netbynet.ru',
				'boturl' => 'netbynet.ru',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '61',
				'botnickname' => 'avtlg.ru',
				'botname' => 'avtlg.ru',
				'boturl' => 'avtlg.ru',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '62',
				'botnickname' => 'mts.ru',
				'botname' => 'mts.ru',
				'boturl' => 'mts.ru',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '63',
				'botnickname' => 'nationalcablenetworks.ru',
				'botname' => 'nationalcablenetworks.ru',
				'boturl' => 'nationalcablenetworks.ru',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '64',
				'botnickname' => 'videos-for-your-business.com',
				'botname' => 'videos-for-your-business.com',
				'boturl' => 'videos-for-your-business.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '65',
				'botnickname' => 'success-seo.com',
				'botname' => 'success-seo.com',
				'boturl' => 'success-seo.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '66',
				'botnickname' => 'webmonetizer.net',
				'botname' => 'webmonetizer.net',
				'boturl' => 'webmonetizer.net',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '67',
				'botnickname' => 'trafficmonetizer.net',
				'botname' => 'trafficmonetizer.net',
				'boturl' => 'trafficmonetizer.net',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '68',
				'botnickname' => 'e-buyeasy.com',
				'botname' => 'e-buyeasy.com',
				'boturl' => 'e-buyeasy.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '69',
				'botnickname' => 'traffic2money.com',
				'botname' => 'traffic2money.com',
				'boturl' => 'traffic2money.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '70',
				'botnickname' => 'sexyali.com',
				'botname' => 'sexyali.com',
				'boturl' => 'sexyali.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '71',
				'botnickname' => 'get-free-social-traffic.com',
				'botname' => 'get-free-social-traffic.com',
				'boturl' => 'get-free-social-traffic.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '72',
				'botnickname' => 'chinese-amezon.com',
				'botname' => 'chinese-amezon.com',
				'boturl' => 'chinese-amezon.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '73',
				'botnickname' => 'erot.co',
				'botname' => 'erot.co',
				'boturl' => 'erot.co',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '74',
				'botnickname' => 'hongfanji.com',
				'botname' => 'hongfanji.com',
				'boturl' => 'hongfanji.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '75',
				'botnickname' => 'video--production.com',
				'botname' => 'video--production.com',
				'boturl' => 'video--production.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '76',
				'botnickname' => 'rankscanner.com',
				'botname' => 'rankscanner.com',
				'boturl' => 'rankscanner.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '77',
				'botnickname' => 'yourserverisdown.com',
				'botname' => 'yourserverisdown.com',
				'boturl' => 'yourserverisdown.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '78',
				'botnickname' => 'free-floating-buttons.com',
				'botname' => 'free-floating-buttons.com',
				'boturl' => 'free-floating-buttons.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '79',
				'botnickname' => 'how-to-earn-quick-money.com',
				'botname' => 'how-to-earn-quick-money.com',
				'boturl' => 'how-to-earn-quick-money.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '80',
				'botnickname' => 'qualitymarketzone.com',
				'botname' => 'qualitymarketzone.com',
				'boturl' => 'qualitymarketzone.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '81',
				'botnickname' => 'best-seo-software.xyz',
				'botname' => 'best-seo-software.xyz',
				'boturl' => 'best-seo-software.xyz',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '82',
				'botnickname' => 'seo-platform.com',
				'botname' => 'seo-platform.com',
				'boturl' => 'seo-platform.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '83',
				'botnickname' => 'rankings-analytics.com',
				'botname' => 'rankings-analytics.com',
				'boturl' => 'rankings-analytics.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '84',
				'botnickname' => 'copyrightclaims.org',
				'botname' => 'copyrightclaims.org',
				'boturl' => 'copyrightclaims.org',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '85',
				'botnickname' => 'snip.to',
				'botname' => 'snip.to',
				'boturl' => 'snip.to',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '86',
				'botnickname' => 'amazonaws.com',
				'botname' => 'amazonaws.com',
				'boturl' => 'amazonaws.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '87',
				'botnickname' => 'top1-seo-service.com',
				'botname' => 'top1-seo-service.com',
				'boturl' => 'top1-seo-service.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '88',
				'botnickname' => 'rusexy.xyz',
				'botname' => 'rusexy.xyz',
				'boturl' => 'rusexy.xyz',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '89',
				'botnickname' => 'share-buttons.xyz',
				'botname' => 'share-buttons.xyz',
				'boturl' => 'share-buttons.xyz',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '90',
				'botnickname' => 'traffic2cash.xyz',
				'botname' => 'traffic2cash.xyz',
				'boturl' => 'traffic2cash.xyz',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '91',
				'botnickname' => 'site-16528012-1.snip.tw',
				'botname' => 'site-16528012-1.snip.tw',
				'boturl' => 'site-16528012-1.snip.tw',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '92',
				'botnickname' => 'website-analyzer.info',
				'botname' => 'website-analyzer.info',
				'boturl' => 'website-analyzer.info',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '93',
				'botnickname' => 'rank-checker.online',
				'botname' => 'rank-checker.online',
				'boturl' => 'rank-checker.online',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '94',
				'botnickname' => 'keywords-monitoring-your-success.com',
				'botname' => 'keywords-monitoring-your-success.com',
				'boturl' => 'keywords-monitoring-your-success.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '95',
				'botnickname' => 'works.if.ua',
				'botname' => 'works.if.ua',
				'boturl' => 'works.if.ua',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '96',
				'botnickname' => 'free-video-tool.com',
				'botname' => 'free-video-tool.com',
				'boturl' => 'free-video-tool.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '97',
				'botnickname' => 'social-traffic-',
				'botname' => 'social-traffic-',
				'boturl' => 'social-traffic-',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '98',
				'botnickname' => 'uptime.com',
				'botname' => 'uptime.com',
				'boturl' => 'uptime.com',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '99',
				'botnickname' => 'social-buttons-ii.xyz',
				'botname' => 'social-buttons-ii.xyz',
				'boturl' => 'social-buttons-ii.xyz',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		),
		array (
				'id' => '100',
				'botnickname' => 'monetizationking.net',
				'botname' => 'monetizationking.net',
				'boturl' => 'monetizationking.net',
				'botip' => '',
				'botobs' => '',
				'botstate' => 'Enabled' 
		) 
);



?>