=== Stop Web Crawlers ===

Contributors:      threenine
Plugin Name:       Stop Web Crawlers
Plugin URI:        http://threenine.co.uk/plugins/stop-web-crawlers/
Tags:              stop web crawlers, Referer Spam, Block spammers, block bot, block bots, block bad bots, stop bot, stop bots, web crawlers
Author URI:        http://threenine.co.uk
Author:            Gary Woodfine
Donate link:       https://www.paypal.me/geekiam
Requires at least: 4.5
Tested up to:      4.5.3
Stable tag:        1.1.0


The simplest and easiet way to stop bad web crawlers, bots  and referrer spammers from targeting your wordpress website


== Description ==


 Stop Web Crawlers has been developed to block referrer spam attacks on your WordPress website.  
 
 Stop Web Crawlers will reduce the likelihood that your site will be crawled by the Referrer spammers like;
 
 	> semalt.com , Darodar.com, buttons-for-website, ilovevitaly.co, screentoolkit.com, myftpupload.com,
 	> best-seo-offer.com,  www.Get-Free-Traffic-Now.com,  best-seo-solution.com,  4webmasters.org,  luxup.ru, 
 	> blackhatworth.com,  7makemoneyonline.com,  priceg.com,  prodvigator.ua, resellerclub.com,  savetubevideo.com,   
 	> kambasoft.com,  socialseet.ru,  superiends.org,  vodkoved.ru,  o-o-8-o-o.ru,  iskalko.ru, websocial.me,  
 	> ykecwqlixx.ru,  slftsdybbg.ru,  seoexperimenty.ru,  darodar.com,  econom.co,  edakgfvwql.ru,  adcash.com, 
 	> adviceforum.info,  hulfingtonpost.com,  europages.com.ru,  gobongo.info,  cenoval.ru,  cityadspix.com
  	>
   
   + 100's of others, 
   
   If these Crawlers attemtp to crawl your website they sent *403 access prohibited error response*  
 
 


The additional functionality planned for this plugin for the future is also to remove Ghost Referrer spammers from accessing your Google Analytics.

  
 There is no need to edit your .htaccess or mess around with robots.txt, all is required is too install the plugin and activate the plugin.  
 
 The plugin is currently designed to run unattended and automatically.
 
 There is a settings section, but this is currently only a placeholder for future functionality, which will be activated in future releases of the plugin.

 Other bots will be added to the block list over time via updates to this plugin. 


== Installation ==
1. Upload the `stop-web-crawlers` folder to the `/wp-content/plugins/` directory
1. Activate the Stop Web Crawlers plugin through the 'Plugins' menu in WordPress
1. Configure the plugin by going to the `Stop Web Crawlers` menu that appears in your admin menu

== Upgrade Notice ==

== Screenshots ==

== Changelog ==

   =1.1.0=
   		Added Logo to Admin Dashboard Menu
   		Add New Web Crawler functionality implemented
   		Dashboard View Revamp
   		Additional Refactoring to improve long term support
   		
   		
   
    =1.0.6=
    	Uodated license header
    	Improved refactoring
    	Added minimum WordPress version check
    	

	= 1.0.5 =
	
		Added functionality for filter not run for logged in users or admin users
	
	= 1.0.4 =
	
		Updated readme text 
	
	= 1.0.3 =
		
		Fix upgrade bug and patched HTML formatting
	
	= 1.0.2 =
		
		Bug fix from a source control merge issue
	
	= 1.0.1 =
		
		Cosmetic changes
	
	= 1.0.0 =
	
		Initial release
		

== Frequently Asked Questions ==



== Donations ==
